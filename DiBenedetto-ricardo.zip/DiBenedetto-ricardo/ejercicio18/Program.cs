using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Geometria;
namespace ejercicio18
{
  class PruebaGeometria
  {
    static void Main(string[] args)
    {

      Console.WriteLine();
      Console.ReadKey();
    }
  }
}
