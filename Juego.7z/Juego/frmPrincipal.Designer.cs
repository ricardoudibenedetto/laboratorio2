﻿namespace Juego
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrincipal));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.mago = new Juego.Mago();
            this.arquero = new Juego.Arquero();
            ((System.ComponentModel.ISupportInitialize)(this.mago)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arquero)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // mago
            // 
            this.mago.Derecho = true;
            this.mago.Image = ((System.Drawing.Image)(resources.GetObject("mago.Image")));
            this.mago.Location = new System.Drawing.Point(399, 38);
            this.mago.Name = "mago";
            this.mago.Size = new System.Drawing.Size(77, 124);
            this.mago.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.mago.TabIndex = 1;
            this.mago.TabStop = false;
            // 
            // arquero
            // 
            this.arquero.Derecho = false;
            this.arquero.Image = ((System.Drawing.Image)(resources.GetObject("arquero.Image")));
            this.arquero.Location = new System.Drawing.Point(12, 38);
            this.arquero.Name = "arquero";
            this.arquero.Size = new System.Drawing.Size(86, 124);
            this.arquero.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.arquero.TabIndex = 0;
            this.arquero.TabStop = false;
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(511, 174);
            this.Controls.Add(this.mago);
            this.Controls.Add(this.arquero);
            this.Name = "FrmPrincipal";
            this.Text = "Form1";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FrmPrincipal_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FrmPrincipal_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.mago)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arquero)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Arquero arquero;
        private Mago mago;
        private System.Windows.Forms.Timer timer1;
    }
}

