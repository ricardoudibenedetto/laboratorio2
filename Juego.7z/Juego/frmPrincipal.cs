﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Juego
{
    public partial class FrmPrincipal : Form
    {
        

        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            foreach(Control a in this.Controls)
            {
                if(a is Personaje)
                {
                    if (((Personaje)a).disparando)
                        ((Personaje)a).Disparar();
                }
            }
        }

        private void FrmPrincipal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 80)
            {
                foreach (Control item in this.Controls)                        
                {
                    if(item is Personaje && ((Personaje)item).Derecho)
                    {
                        ((Personaje)item).disparando = true;
                    }

                }
            }
        }

        private void FrmPrincipal_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                foreach (Control item in this.Controls)
                {
                    if (item is Personaje && ((Personaje)item).Derecho)
                    {
                        ((Personaje)item).disparando = true;
                    }

                }
            }
            else if (e.KeyCode == Keys.Right)
            {
                foreach (Control item in this.Controls)
                {
                    if (item is Personaje && !((Personaje)item).Derecho)
                    {
                        ((Personaje)item).disparando = true;
                    }

                }
            }
        }
    }
}
