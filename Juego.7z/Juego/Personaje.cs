﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Juego
{
    public abstract class Personaje:PictureBox
    {
        public bool Derecho { get; set; }
        public bool disparando;
        Label disparo;
        private bool puedeAgachar;
        public void  Disparar()
        {
            if (disparo is null)
            {

                this.disparo = new Label();
                disparo.Name = "Disparo";
                if (!Derecho)
                    disparo.Text = "->";
                else
                    disparo.Text = "<-";

                disparo.Top = this.Top + (this.Height/2) ;
                disparo.Left = this.Left;
                ((Form)this.Parent).Controls.Add(disparo);
                
            }
            else
            {
                disparo.Left = Derecho ? disparo.Left - 1 : disparo.Left + 1;                
            }

        }
        public void agachar(bool agacha)
        {
            if (puedeAgachar && agacha)
            {
                puedeAgachar = false;
                this.Height = this.Height / 2;
            }
            else if(!puedeAgachar && !agacha) {
                puedeAgachar = true;
                this.Height = this.Height * 2;
            }

        }

    }
}
